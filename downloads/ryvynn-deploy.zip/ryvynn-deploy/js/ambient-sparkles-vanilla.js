(() => {
  // Vanilla JS implementation of a subtle floating sparkles effect.
  // Draws softly drifting particles with random colors between teal and violet.
  const canvas = document.querySelector('canvas.sparkles');
  if (!canvas) return;
  // Respect accessibility preferences: do not animate if reduced motion is requested.
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion) return;

  const ctx = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let width;
  let height;
  let particles = [];
  // Density of particles per pixel. Adjust this value for more or fewer sparkles.
  const density = 0.00008;
  const maxOpacity = 0.7;
  const speedScale = 0.12;

  function createParticles() {
    const area = width * height;
    const count = Math.floor(area * density);
    particles = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        // Random drift velocity; speedScale controls overall motion speed.
        vx: (Math.random() - 0.5) * speedScale,
        vy: (Math.random() - 0.5) * speedScale,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * maxOpacity,
        // Choose a hue between teal (approx 185°) and violet (approx 285°).
        hue: 185 + Math.random() * 100,
      });
    }
  }

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    createParticles();
  }

  function update() {
    ctx.clearRect(0, 0, width, height);
    for (const p of particles) {
      p.x += p.vx;
      p.y += p.vy;
      // Wrap around edges to create continuous drifting.
      if (p.x < 0) p.x += width; else if (p.x > width) p.x -= width;
      if (p.y < 0) p.y += height; else if (p.y > height) p.y -= height;
      ctx.beginPath();
      ctx.fillStyle = `hsla(${p.hue}, 80%, 60%, ${p.opacity})`;
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    requestAnimationFrame(update);
  }

  resize();
  window.addEventListener('resize', resize);
  requestAnimationFrame(update);
})();