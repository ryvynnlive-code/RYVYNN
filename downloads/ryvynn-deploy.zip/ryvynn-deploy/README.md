# RYVYNN Static Deployment

This folder contains a fully self-contained static build of the RYVYNN landing page with ambient sparkles, glassmorphism call‑to‑action buttons, and a flame logo. It is designed for zero-surveillance operation: no external trackers, no analytics, and no third‑party requests.

## Files

| File/Folder | Purpose |
|---|---|
| `index.html` | Main landing page. Contains the HTML markup, inline styles, and references to the sparkles script and assets. |
| `assets/ryvynn-logo.svg` | Flame logo used on the page. An SVG with a teal‑to‑violet gradient matching the RYVYNN palette. |
| `js/ambient-sparkles-vanilla.js` | Standalone JavaScript that renders subtle floating sparkles on a `<canvas>` element. Respects `prefers‑reduced‑motion` for accessibility. |
| `vercel.json` | Configuration for Vercel deployment. Sets strict security headers, enables long‑term caching for assets, and ensures `index.html` is not cached so updates propagate. |

## Local Preview

You can preview the page locally using any static file server. For example:

```bash
cd ryvynn-deploy
npx serve .
```

Then visit http://localhost:3000 in your browser.

## Deploying to Vercel

1. Ensure you are logged in to Vercel: `vercel login`.
2. From within `ryvynn-deploy`, run:

   ```bash
   vercel --prod
   ```

   Vercel will detect the static build and deploy it. The `vercel.json` file automatically applies the security headers and caching policies.

## Deploying to Netlify

1. Install the Netlify CLI if you haven't already: `npm install -g netlify-cli`.
2. Log in: `netlify login`.
3. Deploy the folder:

   ```bash
   netlify deploy --dir . --prod
   ```

The page should be available at the URL provided by Netlify. You can point your domain (e.g. `ryvynn.live`) to Netlify if desired.

## DNS Configuration

If using Vercel, configure your DNS to point to `76.76.21.21` for the `@` record. Optionally, add a CNAME record for `www` pointing to `cname.vercel-dns.com`.

## Accessibility and Performance

- The ambient sparkles effect is disabled automatically when the user prefers reduced motion.
- All assets (CSS, JS, images) are served from your domain only; there are no requests to external CDNs or trackers.
- The call‑to‑action buttons use a semi‑transparent glass effect and glow subtly when hovered.
- Security headers include a strict Content Security Policy (`default-src 'self'`), HSTS, and referrer policy.