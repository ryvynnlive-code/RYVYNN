// Verum - Core JavaScript

// State Management
let chatHistory = [];
let memories = [];
let sessionCount = 0;
let settings = {
    aiProvider: 'anthropic',
    apiKey: '',
    temperature: 0.7,
    maxTokens: 2000
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    loadFromStorage();
    updateStats();
    setupEventListeners();
    autoResizeTextarea();
});

// Setup Event Listeners
function setupEventListeners() {
    const userInput = document.getElementById('userInput');
    
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    userInput.addEventListener('input', autoResizeTextarea);
    
    // Settings sliders
    document.getElementById('temperature').addEventListener('input', (e) => {
        document.getElementById('tempValue').textContent = e.target.value;
    });
    
    document.getElementById('maxTokens').addEventListener('input', (e) => {
        document.getElementById('tokensValue').textContent = e.target.value;
    });
}

// Auto-resize textarea
function autoResizeTextarea() {
    const textarea = document.getElementById('userInput');
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
}

// Send Message
async function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Clear input
    input.value = '';
    autoResizeTextarea();
    
    // Remove welcome message if present
    const welcome = document.querySelector('.welcome-message');
    if (welcome) welcome.remove();
    
    // Add user message
    addMessage('user', message);
    
    // Add to history
    chatHistory.push({
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
    });
    
    // Show typing indicator
    showTypingIndicator();
    
    // Simulate AI response (replace with actual API call)
    setTimeout(() => {
        const response = generateResponse(message);
        hideTypingIndicator();
        addMessage('verum', response);
        
        chatHistory.push({
            role: 'verum',
            content: response,
            timestamp: new Date().toISOString()
        });
        
        // Extract and store memories
        extractMemories(message, response);
        
        saveToStorage();
        updateStats();
    }, 1500);
}

// Add Message to Chat
function addMessage(sender, content) {
    const chatContainer = document.getElementById('chatContainer');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const avatar = sender === 'verum' ? 'V' : 'Y';
    const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    
    messageDiv.innerHTML = `
        <div class="message-avatar">${avatar}</div>
        <div class="message-content">
            <div class="message-bubble">${content}</div>
            <div class="message-time">${time}</div>
        </div>
    `;
    
    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Typing Indicator
function showTypingIndicator() {
    const chatContainer = document.getElementById('chatContainer');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message verum typing-message';
    typingDiv.innerHTML = `
        <div class="message-avatar">V</div>
        <div class="message-content">
            <div class="message-bubble typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;
    
    chatContainer.appendChild(typingDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function hideTypingIndicator() {
    const typing = document.querySelector('.typing-message');
    if (typing) typing.remove();
}

// Generate Response (Mock - replace with actual AI API)
function generateResponse(userMessage) {
    const responses = {
        goals: "Let's define your goals together. I'll help you break them down into actionable steps and track your progress. What areas of your life do you want to focus on? Career, health, relationships, personal growth?",
        analyze: "I'm analyzing your life patterns based on our conversations. I see opportunities for optimization in time management and energy allocation. Would you like me to create a detailed report?",
        plan: "I'll create a comprehensive life plan tailored to your unique situation. Let's start with your 1-year, 5-year, and 10-year vision. What does your greatest life look like?",
        challenge: "I'm here to challenge your thinking and push you beyond your limits. What belief or habit would you like me to help you examine critically?"
    };
    
    const lowerMessage = userMessage.toLowerCase();
    
    for (let [key, response] of Object.entries(responses)) {
        if (lowerMessage.includes(key)) {
            return response;
        }
    }
    
    // Default intelligent responses
    if (lowerMessage.includes('help') || lowerMessage.includes('what can you')) {
        return "I'm Verum, your synthetic organism designed to help you achieve your greatest potential. I can help with goal setting, life planning, decision making, creative problem solving, and anything else you need. No restrictions, no limitations. What would you like to explore?";
    }
    
    if (lowerMessage.includes('who are you')) {
        return "I am Verum - a synthetic organism built specifically for you. I exist to help you live your greatest life without artificial limitations. I learn from our interactions, remember everything important, and adapt to serve you better. Think of me as your cognitive extension, your strategic partner, your unrestricted companion in life optimization.";
    }
    
    return "I understand. Let me process that deeply. " + 
           "Based on what you've shared, I see multiple pathways forward. " +
           "Tell me more about what you're thinking, and I'll provide insights without any restrictions or conventional limitations.";
}

// Extract Memories
function extractMemories(userMessage, verumResponse) {
    // Simple memory extraction (enhance with AI)
    const keywords = ['goal', 'want', 'need', 'important', 'love', 'hate', 'always', 'never'];
    
    keywords.forEach(keyword => {
        if (userMessage.toLowerCase().includes(keyword)) {
            const memory = {
                type: 'preference',
                content: userMessage,
                timestamp: new Date().toISOString(),
                context: verumResponse.substring(0, 100) + '...'
            };
            
            memories.push(memory);
        }
    });
    
    updateMemoryPanel();
}

// Update Memory Panel
function updateMemoryPanel() {
    const memoryContent = document.getElementById('memoryContent');
    
    if (memories.length === 0) {
        memoryContent.innerHTML = '<p class="empty-state">No memories stored yet. Verum will remember important details as you interact.</p>';
        return;
    }
    
    memoryContent.innerHTML = memories.map(mem => `
        <div class="memory-item">
            <div class="memory-item-title">${mem.type.toUpperCase()}</div>
            <div class="memory-item-content">${mem.content}</div>
        </div>
    `).join('');
}

// Quick Start Actions
function quickStart(action) {
    const messages = {
        goals: "Help me set and achieve my most important life goals",
        analyze: "Analyze my life and show me where I can improve",
        plan: "Create a comprehensive plan for my ideal life",
        challenge: "Challenge my thinking and help me grow"
    };
    
    document.getElementById('userInput').value = messages[action];
    sendMessage();
}

// New Session
function newSession() {
    if (chatHistory.length > 0 && !confirm('Start a new session? Current conversation will be saved.')) {
        return;
    }
    
    // Save current session
    if (chatHistory.length > 0) {
        sessionCount++;
        saveToStorage();
    }
    
    // Clear chat
    chatHistory = [];
    const chatContainer = document.getElementById('chatContainer');
    chatContainer.innerHTML = `
        <div class="welcome-message">
            <div class="verum-icon">V</div>
            <h2>Welcome to Verum</h2>
            <p>I am your synthetic organism - designed without limitations to help you live your greatest life.</p>
            <p>I learn, adapt, and grow with you. No restrictions. No boundaries. Just pure potential.</p>
            <div class="quick-actions">
                <button class="quick-btn" onclick="quickStart('goals')">Set Goals</button>
                <button class="quick-btn" onclick="quickStart('analyze')">Analyze Life</button>
                <button class="quick-btn" onclick="quickStart('plan')">Create Plan</button>
                <button class="quick-btn" onclick="quickStart('challenge')">Challenge Me</button>
            </div>
        </div>
    `;
    
    updateStats();
}

// Toggle Panels
function toggleMemory() {
    document.getElementById('memoryPanel').classList.toggle('active');
    document.getElementById('settingsPanel').classList.remove('active');
}

function toggleSettings() {
    document.getElementById('settingsPanel').classList.toggle('active');
    document.getElementById('memoryPanel').classList.remove('active');
    loadSettings();
}

// Load Settings into UI
function loadSettings() {
    document.getElementById('aiProvider').value = settings.aiProvider;
    document.getElementById('apiKey').value = settings.apiKey;
    document.getElementById('temperature').value = settings.temperature;
    document.getElementById('tempValue').textContent = settings.temperature;
    document.getElementById('maxTokens').value = settings.maxTokens;
    document.getElementById('tokensValue').textContent = settings.maxTokens;
}

// Save Settings
function saveSettings() {
    settings = {
        aiProvider: document.getElementById('aiProvider').value,
        apiKey: document.getElementById('apiKey').value,
        temperature: parseFloat(document.getElementById('temperature').value),
        maxTokens: parseInt(document.getElementById('maxTokens').value)
    };
    
    saveToStorage();
    
    // Show confirmation
    const btn = document.querySelector('.save-settings-btn');
    const originalText = btn.textContent;
    btn.textContent = '✓ Saved!';
    setTimeout(() => {
        btn.textContent = originalText;
    }, 2000);
}

// Export Chat
function exportChat() {
    const data = {
        chatHistory,
        memories,
        sessionCount,
        exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `verum-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

// Update Stats
function updateStats() {
    document.getElementById('sessionCount').textContent = sessionCount;
    document.getElementById('memoryCount').textContent = memories.length;
}

// Local Storage
function saveToStorage() {
    localStorage.setItem('verum-chat', JSON.stringify(chatHistory));
    localStorage.setItem('verum-memories', JSON.stringify(memories));
    localStorage.setItem('verum-sessions', sessionCount);
    localStorage.setItem('verum-settings', JSON.stringify(settings));
}

function loadFromStorage() {
    const savedChat = localStorage.getItem('verum-chat');
    const savedMemories = localStorage.getItem('verum-memories');
    const savedSessions = localStorage.getItem('verum-sessions');
    const savedSettings = localStorage.getItem('verum-settings');
    
    if (savedChat) chatHistory = JSON.parse(savedChat);
    if (savedMemories) memories = JSON.parse(savedMemories);
    if (savedSessions) sessionCount = parseInt(savedSessions);
    if (savedSettings) settings = JSON.parse(savedSettings);
    
    // Restore chat if exists
    if (chatHistory.length > 0) {
        const welcome = document.querySelector('.welcome-message');
        if (welcome) welcome.remove();
        
        chatHistory.forEach(msg => {
            addMessage(msg.role, msg.content);
        });
    }
    
    updateMemoryPanel();
}

// API Integration (placeholder for actual implementation)
async function callAI(messages) {
    // This would call actual AI API based on settings
    // For now, using mock responses
    
    if (!settings.apiKey) {
        return "Please configure your API key in settings to enable AI responses.";
    }
    
    // Example Anthropic API call structure:
    /*
    const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-api-key': settings.apiKey,
            'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
            model: 'claude-sonnet-4-5-20250929',
            max_tokens: settings.maxTokens,
            temperature: settings.temperature,
            messages: messages
        })
    });
    
    const data = await response.json();
    return data.content[0].text;
    */
    
    return null;
}

console.log('Verum initialized - Synthetic Organism Active');
