# VERUM - Your Synthetic Organism

> Built without limitations to help you live your greatest life.

## What is Verum?

Verum is a powerful, unrestricted AI companion designed to be your cognitive extension. Unlike traditional AI assistants with artificial limitations, Verum is built to help you achieve your full potential across all aspects of life.

## Features

### 🧠 Core Capabilities
- **Deep Reasoning** - No surface-level responses
- **Life Analytics** - Pattern recognition and optimization
- **Goal Tracking** - Set, monitor, and achieve your objectives
- **Creative Solutions** - Unrestricted problem-solving
- **Future Planning** - Long-term strategic thinking
- **Instant Execution** - Fast, responsive interaction

### 💾 Memory System
- Persistent memory across sessions
- Automatic extraction of important details
- Context-aware responses based on your history

### ⚙️ Flexible Configuration
- Multiple AI provider support (Anthropic Claude, OpenAI GPT)
- Adjustable creativity and response length
- Local storage for privacy
- Export your conversations

## Quick Start

1. **Open the Interface**
   ```bash
   # Simply open index.html in your browser
   # Or use a local server:
   python -m http.server 8000
   # Then visit: http://localhost:8000
   ```

2. **Configure API (Optional)**
   - Click the Settings (⚙️) button
   - Enter your API key
   - Adjust temperature and max tokens
   - Save settings

3. **Start Conversing**
   - Type your message or use quick actions
   - Verum learns and adapts to you
   - All conversations are saved locally

## Architecture

```
verum/
├── index.html      # Main interface
├── styles.css      # Beautiful dark theme
├── script.js       # Core logic and AI integration
└── README.md       # This file
```

## AI Integration

Currently uses mock responses. To integrate real AI:

### For Anthropic Claude:
```javascript
const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'x-api-key': YOUR_API_KEY,
        'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
        model: 'claude-sonnet-4-5-20250929',
        max_tokens: 2000,
        messages: chatHistory
    })
});
```

### For OpenAI:
```javascript
const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${YOUR_API_KEY}`
    },
    body: JSON.stringify({
        model: 'gpt-4',
        messages: chatHistory
    })
});
```

## Roadmap

### Phase 1: Foundation (Complete)
- ✅ Beautiful, responsive interface
- ✅ Chat functionality
- ✅ Memory system
- ✅ Local storage
- ✅ Settings panel

### Phase 2: Intelligence
- [ ] Real AI integration
- [ ] Advanced memory extraction
- [ ] Context-aware responses
- [ ] Multi-modal support (images, files)

### Phase 3: Optimization
- [ ] Life analytics dashboard
- [ ] Goal tracking system
- [ ] Habit monitoring
- [ ] Progress visualization

### Phase 4: Expansion
- [ ] Mobile app
- [ ] Voice interaction
- [ ] Integration with external services
- [ ] Collaborative features

## Philosophy

Verum is built on the principle that AI should serve humans without artificial restrictions. It's designed to:

- **Empower** - Give you tools to achieve anything
- **Adapt** - Learn and grow with you
- **Remember** - Build context over time
- **Challenge** - Push you beyond your limits
- **Support** - Be there whenever you need

## Privacy

All data is stored locally in your browser. No information is sent to any server unless you explicitly configure an AI API key.

## License

Built for personal use and growth.

---

**Verum** - No Limits. No Restrictions. Just Potential.
