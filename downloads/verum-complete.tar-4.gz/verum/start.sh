#!/bin/bash
echo "Starting Verum..."
cd "$(dirname "$0")"
node server.js
