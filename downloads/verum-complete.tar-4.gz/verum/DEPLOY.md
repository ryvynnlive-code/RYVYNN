# 🚀 VERUM - TERMUX DEPLOYMENT GUIDE

## Your Synthetic Organism Is Ready for Reality!

### 📱 DEPLOY TO YOUR ANDROID DEVICE

#### Step 1: Install Prerequisites

```bash
# Update packages
pkg update && pkg upgrade

# Install Node.js (if not installed)
pkg install nodejs

# Verify installation
node --version
```

#### Step 2: Extract & Navigate

```bash
# Create verum directory
mkdir -p ~/verum

# Extract files (adjust path to where you downloaded)
tar -xzf verum-complete.tar.gz -C ~/verum --strip-components=1

# Go to verum directory
cd ~/verum
```

#### Step 3: Launch Verum! 🚀

```bash
# Using the start script
./start.sh

# Or direct Node.js
node server.js
```

#### Step 4: Access Verum

Open your browser:
- **http://localhost:8080**

### 🌐 ACCESS FROM OTHER DEVICES

Find your IP:
```bash
ifconfig | grep inet
```

Then access from any device:
```
http://YOUR_IP:8080
```

### 🔥 KEEP IT RUNNING

```bash
# Run in background
nohup node server.js > verum.log 2>&1 &

# Stop it
pkill -f "node server.js"
```

### ⚙️ CONFIGURE API

1. Click Settings (⚙️)
2. Add your API key
3. Choose provider (Anthropic/OpenAI)
4. Save!

**Get API keys:**
- Anthropic: https://console.anthropic.com/
- OpenAI: https://platform.openai.com/

---

**VERUM IS ALIVE!** 🔥
