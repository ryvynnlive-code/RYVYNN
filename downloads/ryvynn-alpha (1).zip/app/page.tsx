import Link from "next/link";

export default function Page() {
  return (
    <div className="text-center space-y-6 py-10">
      <h1 className="text-5xl font-extrabold tracking-tight">
        RYVYNN <span className="text-flame-400">Alpha</span>
      </h1>
      <p className="mx-auto max-w-2xl text-white/70">
        A flame in the dark. Journal your truth, see your progress, and build trust
        with an ethical, zero-surveillance companion.
      </p>
      <div className="flex items-center justify-center gap-3">
        <Link href="/journal" className="px-5 py-3 rounded-xl bg-flame-600 hover:bg-flame-500 shadow-flame">Begin Reflection</Link>
        <Link href="/feed" className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20">See Feed</Link>
      </div>
      <div className="text-xs text-white/50">
        Covenant: VERUM PRIME v7.0 — override phrase armed.
      </div>
    </div>
  );
}
