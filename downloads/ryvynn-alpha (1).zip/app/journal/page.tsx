import JournalEditor from "@/components/JournalEditor";

export default function JournalPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Journal</h1>
      <JournalEditor />
    </div>
  );
}
