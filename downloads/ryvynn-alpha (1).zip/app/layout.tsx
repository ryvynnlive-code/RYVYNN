import "./globals.css";
import { ReactNode } from "react";
import NavBar from "@/components/NavBar";
import FlameBackground from "@/components/FlameBackground";

export const metadata = {
  title: "RYVYNN — Alpha",
  description: "AI Wisdom. Human Heart. Zero Surveillance."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen antialiased selection:bg-flame-600/60 selection:text-white">
        <FlameBackground />
        <NavBar />
        <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
        <footer className="mx-auto max-w-5xl px-4 py-10 text-sm text-white/50">
          © 2025 RYVYNN / AoNiXx — “AI Wisdom. Human Heart. Zero Surveillance.”
        </footer>
      </body>
    </html>
  );
}
