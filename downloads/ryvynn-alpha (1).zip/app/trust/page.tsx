export default function TrustPage() {
  const checks = [
    { name: "Zero-Ads", status: "Pass" },
    { name: "No trackers", status: "Pass" },
    { name: "Local-first UI", status: "Enabled" },
    { name: "Encryption at rest (DB)", status: "Enabled" },
    { name: "RLS policies", status: "Enabled" },
    { name: "CSP headers", status: "Enabled" }
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Trust Dashboard</h1>
      <p className="text-white/70">Public signals that your data sovereignty remains intact.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {checks.map((c) => (
          <div key={c.name} className="rounded-xl bg-black/40 border border-white/10 p-4">
            <div className="text-sm text-white/60">{c.name}</div>
            <div className="text-lg font-semibold mt-1">{c.status}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
