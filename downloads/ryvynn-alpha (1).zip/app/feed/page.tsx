import dynamic from "next/dynamic";
const FeedList = dynamic(() => import("@/components/FeedList"), { ssr: false });

export default function FeedPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Feed</h1>
      <FeedList />
    </div>
  );
}
