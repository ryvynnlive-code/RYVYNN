"use client";

import { motion } from "framer-motion";
import { clsx } from "clsx";

export default function FlameBackground({ className = "" }: { className?: string }) {
  return (
    <div className={clsx("relative isolate", className)}>
      <motion.div
        className="pointer-events-none absolute inset-0 -z-10 bg-flame-gradient opacity-80"
        initial={{ opacity: 0.6 }}
        animate={{ opacity: [0.6, 0.95, 0.6] }}
        transition={{ duration: 10, repeat: Infinity, repeatType: "mirror" }}
      />
      <motion.div
        className="pointer-events-none absolute -top-20 left-1/2 -translate-x-1/2 w-[60vw] h-[60vw] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(249,115,22,0.25) 0%, rgba(124,45,18,0.05) 60%, rgba(11,11,14,0) 100%)" }}
        animate={{ scale: [0.9, 1.1, 0.9] }}
        transition={{ duration: 14, repeat: Infinity, repeatType: "mirror" }}
      />
    </div>
  );
}
