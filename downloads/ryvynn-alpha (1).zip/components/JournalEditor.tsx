"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Loader2, Sparkles } from "lucide-react";

export default function JournalEditor() {
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string|null>(null);

  async function saveEntry() {
    if (!content.trim()) return;
    setSaving(true);
    setMessage(null);
    try {
      const { error } = await supabase.from("entries").insert({ content });
      if (error) throw error;
      setContent("");
      setMessage("Saved. Keep going.");
    } catch (e: any) {
      setMessage(e.message ?? "Error saving entry.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-2xl bg-black/40 border border-white/10 p-4 shadow-flame">
      <div className="flex items-center gap-2 mb-2 text-flame-300">
        <Sparkles className="w-4 h-4" />
        <span className="text-sm">Whisper to the flame. Only truth survives.</span>
      </div>
      <textarea
        className="w-full h-40 rounded-xl p-3 bg-black/50 border border-white/10 outline-none focus:border-flame-400 transition"
        placeholder="What truth needs to be spoken today?"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
      <div className="mt-3 flex items-center gap-3">
        <button
          onClick={saveEntry}
          disabled={saving || !content.trim()}
          className="px-4 py-2 rounded-xl bg-flame-600 hover:bg-flame-500 disabled:opacity-50"
        >
          {saving ? <span className="inline-flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" />Saving</span> : "Save entry"}
        </button>
        {message && <p className="text-sm text-white/70">{message}</p>}
      </div>
    </div>
  );
}
