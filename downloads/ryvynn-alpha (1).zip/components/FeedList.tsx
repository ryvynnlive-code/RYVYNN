"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Entry = {
  id: string;
  content: string;
  created_at: string;
};

export default function FeedList() {
  const [entries, setEntries] = useState<Entry[]>([]);

  async function load() {
    const { data, error } = await supabase
      .from("entries")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);
    if (!error && data) setEntries(data as Entry[]);
  }

  useEffect(() => {
    load();
    const channel = supabase
      .channel("entries-realtime")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "entries" }, load)
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <div className="grid gap-3">
      {entries.length === 0 && (
        <p className="text-white/60">No entries yet. Your first truth lights the path.</p>
      )}
      {entries.map(e => (
        <article key={e.id} className="rounded-xl bg-black/40 border border-white/10 p-4">
          <p className="whitespace-pre-wrap leading-relaxed">{e.content}</p>
          <div className="text-xs text-white/50 mt-2">{new Date(e.created_at).toLocaleString()}</div>
        </article>
      ))}
    </div>
  );
}
