"use client";

import Link from "next/link";
import { Flame } from "lucide-react";

export default function NavBar() {
  return (
    <header className="sticky top-0 z-20 backdrop-blur bg-black/40 border-b border-white/5">
      <div className="mx-auto max-w-5xl px-4 py-3 flex items-center gap-3">
        <Flame className="w-5 h-5 text-flame-400" />
        <Link href="/" className="font-semibold tracking-wide">RYVYNN</Link>
        <nav className="ml-auto flex items-center gap-4 text-sm">
          <Link className="hover:text-flame-300" href="/journal">Journal</Link>
          <Link className="hover:text-flame-300" href="/feed">Feed</Link>
          <Link className="hover:text-flame-300" href="/trust">Trust</Link>
          <Link className="hover:text-flame-300" href="/login">Login</Link>
        </nav>
      </div>
    </header>
  );
}
