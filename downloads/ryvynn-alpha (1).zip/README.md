# RYVYNN Alpha (Flame)

**Live, testable MVP** for journaling, feed, trust dashboard, and covenant heartbeat.

## Stack
- Next.js 15 (App Router), React 18
- Supabase (Auth + Postgres)
- Tailwind (Flame theme)
- Vercel (deploy), GitHub Actions (CI)

## Quick Start

1) Install
```bash
npm i
```

2) Configure env
- Copy `.env.example` to `.env.local` and fill:
  - `NEXT_PUBLIC_SUPABASE_URL`
  - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

3) Supabase SQL (Auth + Tables + RLS)
- Run `sql/schema.sql` inside Supabase SQL editor.

4) Dev
```bash
npm run dev
```

5) Deploy
- Push to GitHub. Configure Vercel project. Add env vars.
- (Optional CI) Add `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID` to GitHub repo secrets.

## Routes
- `/` Landing
- `/login` Email magic link
- `/journal` Create entry
- `/feed` View entries
- `/trust` Basic trust metrics
- `/api/heartbeat` Covenant status JSON

## License
© 2025 RYVYNN / AoNiXx. All rights reserved.
