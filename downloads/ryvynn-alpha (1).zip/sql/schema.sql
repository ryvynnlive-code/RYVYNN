-- RYVYNN Alpha Schema (Supabase)

-- Enable UUID extension (if not already)
create extension if not exists "uuid-ossp";

-- Entries table
create table if not exists public.entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete set null,
  content text not null,
  created_at timestamp with time zone default now()
);

-- Profiles (optional for future expansion)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamp with time zone default now()
);

-- Basic trust metrics (placeholder, can be computed)
create table if not exists public.trust_metrics (
  id uuid primary key default uuid_generate_v4(),
  metric text not null,
  value numeric,
  created_at timestamp with time zone default now()
);

-- Row-Level Security
alter table public.entries enable row level security;
alter table public.profiles enable row level security;
alter table public.trust_metrics enable row level security;

-- Policies: Allow read for all (public alpha), insert for authenticated users
create policy "Entries are viewable by everyone" on public.entries
  for select using (true);

create policy "Authenticated users can insert entries" on public.entries
  for insert with check (auth.role() = 'authenticated');

-- Profiles policies
create policy "Profiles readable by self or public" on public.profiles
  for select using (true);

create policy "Upsert own profile" on public.profiles
  for insert with check (auth.uid() = id);

create policy "Update own profile" on public.profiles
  for update using (auth.uid() = id);

-- Trust metrics: read for all, write restricted (service role later)
create policy "Trust metrics readable by all" on public.trust_metrics
  for select using (true);

-- Realtime for entries
-- In Supabase: Enable Realtime for the 'entries' table via the dashboard.
