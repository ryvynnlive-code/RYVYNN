import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        flame: {
          50: "#fff7ed",
          100: "#ffedd5",
          200: "#fed7aa",
          300: "#fdba74",
          400: "#fb923c",
          500: "#f97316",
          600: "#ea580c",
          700: "#c2410c",
          800: "#9a3412",
          900: "#7c2d12"
        },
        coal: "#0b0b0e"
      },
      backgroundImage: {
        "flame-gradient": "radial-gradient(60% 60% at 50% 50%, rgba(249,115,22,0.25) 0%, rgba(124,45,18,0.1) 40%, rgba(11,11,14,0) 70%)"
      },
      boxShadow: {
        flame: "0 10px 25px -5px rgba(249,115,22,0.4), 0 10px 10px -5px rgba(249,115,22,0.2)"
      }
    }
  },
  plugins: []
};
export default config;
