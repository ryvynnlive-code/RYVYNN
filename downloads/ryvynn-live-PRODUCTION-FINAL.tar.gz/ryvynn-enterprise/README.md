# RYVYNN Enterprise v1.0

**Privacy-First Healing AI Platform**  
*Rising from our darkest places*

## 🎯 Core Features

- **Zero-Knowledge Architecture**: AES-256-GCM client-side encryption
- **Soul Mirror Avatar**: Evolving sacred geometry based on healing journey
- **Trust Metrics**: Streak tracking, sentiment analysis, engagement scoring
- **Three-Tier System**: Free (3/month) → Premium (unlimited) → White-Label (orgs)
- **Supabase Auth**: Secure user authentication
- **Stripe Billing**: Subscription management
- **Next.js 15**: App Router with Server Components

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18.17+
- PostgreSQL database (Supabase recommended)
- Stripe account
- Git

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
```

Fill in required variables:
- `ENCRYPTION_KEY`: Generate with `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`
- Supabase credentials from your project dashboard
- Stripe keys from your Stripe dashboard

### 3. Initialize Database
```bash
npx prisma migrate dev --name init
npx prisma generate
```

### 4. Run Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📦 Deployment

### Vercel (Recommended)

1. **Push to GitHub**:
```bash
git init
git add .
git commit -m "RYVYNN Enterprise v1.0"
git branch -M main
git remote add origin your-repo-url
git push -u origin main
```

2. **Deploy via Vercel CLI**:
```bash
npm i -g vercel
vercel login
vercel --prod
```

3. **Configure Environment Variables** in Vercel dashboard:
   - Add all variables from `.env.example`
   - Ensure `DATABASE_URL` uses connection pooler
   - Add `DIRECT_URL` for migrations

4. **Run Migrations**:
```bash
vercel env pull .env.production.local
npx prisma migrate deploy
```

### Stripe Webhook Setup

1. Create webhook endpoint: `https://your-domain.vercel.app/api/stripe/webhook`
2. Select events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
3. Copy webhook secret to `STRIPE_WEBHOOK_SECRET`

---

## 🏗️ Architecture

```
ryvynn-enterprise/
├── app/
│   ├── api/              # API routes
│   │   ├── confession/   # Encrypted confession creation
│   │   ├── trust/        # Trust metrics
│   │   ├── user/         # User management
│   │   └── stripe/       # Payment webhooks
│   ├── auth/             # Authentication pages
│   ├── (dashboard)/      # Protected dashboard
│   └── page.tsx          # Landing page
├── components/
│   ├── sacred-geometry/  # Soul Mirror avatar
│   └── ui/               # Reusable UI components
├── lib/
│   ├── encryption.ts     # AES-256-GCM utilities
│   ├── prisma/           # Database client
│   ├── supabase/         # Auth clients
│   └── stripe/           # Payment utilities
└── prisma/
    └── schema.prisma     # Database schema
```

---

## 🔒 Security

- **Client-side encryption**: Confessions encrypted before leaving browser
- **Zero-knowledge**: Server cannot decrypt user content
- **Strict CSP**: Content Security Policy headers
- **HTTPS only**: Enforced in production
- **Rate limiting**: Configured via Vercel Edge Config

---

## 💰 Subscription Tiers

| Tier | Price | Confessions | AI Insights | White-Label |
|------|-------|------------|-------------|-------------|
| **Free** | $0/mo | 3/month | ❌ | ❌ |
| **Premium** | $12/mo | Unlimited | ✅ | ❌ |
| **White-Label** | $99/mo | Unlimited | ✅ | ✅ |

---

## 🎨 Brand Standards

**Colors**:
- Cosmic Background: `#0B001A`
- Electric Violet: `#A663FF`
- Golden Amber: `#FFD86E`

**Fonts**:
- Display: Poppins
- Body: Inter
- Serif: Playfair Display

**Tone**: Calm × Signal — luminous precision over noise

---

## 📊 Monitoring

- **Vercel Analytics**: Built-in performance monitoring
- **Stripe Dashboard**: Revenue and subscription metrics
- **Supabase Logs**: Auth and database queries

---

## 🛠️ Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: Supabase
- **Payments**: Stripe
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion
- **Hosting**: Vercel

---

## 📝 License

Proprietary - RYVYNN © 2024

---

## 🌟 Philosophy

*"AI Wisdom • Human Heart • Zero Surveillance"*

RYVYNN believes healing happens in safety. We've built a sanctuary where your darkest confessions remain yours alone—encrypted, private, sacred.

---

**Need Support?** shawn@ryvynn.com
