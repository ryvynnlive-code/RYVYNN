import type { Metadata } from 'next';
import { Inter, Poppins, Playfair_Display } from 'next/font/google';
import './globals.css';
import { Toaster } from 'react-hot-toast';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const poppins = Poppins({ 
  weight: ['600', '700', '800'],
  subsets: ['latin'],
  variable: '--font-poppins'
});
const playfair = Playfair_Display({ 
  subsets: ['latin'],
  variable: '--font-playfair'
});

export const metadata: Metadata = {
  title: 'RYVYNN — Privacy-First Healing AI',
  description: 'Your confessions. Your healing. Your privacy. Zero surveillance. Military-grade encryption.',
  keywords: ['mental health', 'AI therapy', 'privacy', 'encryption', 'healing', 'confession'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${poppins.variable} ${playfair.variable}`}>
      <body>
        {children}
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#1A0033',
              color: '#fff',
              border: '1px solid rgba(166, 99, 255, 0.3)',
            },
            success: {
              iconTheme: {
                primary: '#A663FF',
                secondary: '#fff',
              },
            },
            error: {
              iconTheme: {
                primary: '#FF6B9D',
                secondary: '#fff',
              },
            },
          }}
        />
      </body>
    </html>
  );
}
