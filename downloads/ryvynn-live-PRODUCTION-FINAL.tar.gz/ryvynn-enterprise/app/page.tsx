import Link from 'next/link';
import { ArrowRight, Shield, Sparkles, Zap } from 'lucide-react';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-cosmic-dark text-white overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-6">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-electric/20 rounded-full blur-[128px] animate-pulse-slow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gold-amber/20 rounded-full blur-[128px] animate-pulse-slow" style={{ animationDelay: '1s' }} />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto text-center">
          {/* Logo */}
          <div className="mb-8">
            <h1 className="text-6xl md:text-8xl font-display font-bold bg-gradient-cosmic bg-clip-text text-transparent">
              RYVYNN
            </h1>
            <p className="text-xl md:text-2xl text-white/60 mt-2 font-serif italic">
              Rising from darkness
            </p>
          </div>

          {/* Tagline */}
          <h2 className="text-4xl md:text-6xl font-display font-bold mb-8 leading-tight">
            Privacy-First Healing AI<br />
            <span className="bg-gradient-cosmic bg-clip-text text-transparent">
              Zero Surveillance
            </span>
          </h2>

          <p className="text-xl md:text-2xl text-white/70 mb-12 max-w-3xl mx-auto leading-relaxed">
            Your confessions. Your healing. Your privacy. Encrypted end-to-end with AES-256-GCM. 
            No data harvesting. Ever.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
            <Link
              href="/auth"
              className="group px-10 py-5 bg-gradient-cosmic rounded-xl font-display font-semibold text-lg shadow-2xl hover:shadow-violet-electric/50 transition-all duration-300 flex items-center gap-3"
            >
              Start Your Journey
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>

            <Link
              href="/pricing"
              className="px-10 py-5 border-2 border-violet-electric/30 rounded-xl font-display font-semibold text-lg hover:border-violet-electric hover:bg-violet-electric/10 transition-all duration-300"
            >
              View Pricing
            </Link>
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-8 text-sm text-white/50">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-violet-electric" />
              <span>AES-256-GCM Encryption</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-gold-amber" />
              <span>AI-Powered Insights</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-ember-glow" />
              <span>Zero Data Harvesting</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-32 px-6">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-4xl md:text-5xl font-display font-bold text-center mb-20">
            Healing Through{' '}
            <span className="bg-gradient-cosmic bg-clip-text text-transparent">
              Sacred Privacy
            </span>
          </h3>

          <div className="grid md:grid-cols-3 gap-12">
            {/* Feature 1 */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-cosmic opacity-0 group-hover:opacity-10 blur-xl transition-opacity duration-500" />
              <div className="relative p-8 rounded-2xl border border-violet-electric/20 hover:border-violet-electric/50 transition-all duration-300">
                <div className="w-16 h-16 rounded-xl bg-violet-electric/10 flex items-center justify-center mb-6">
                  <Shield className="w-8 h-8 text-violet-electric" />
                </div>
                <h4 className="text-2xl font-display font-bold mb-4">
                  Military-Grade Encryption
                </h4>
                <p className="text-white/60 leading-relaxed">
                  Every confession is encrypted with AES-256-GCM before leaving your device. 
                  Not even RYVYNN can read your private thoughts.
                </p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-cosmic opacity-0 group-hover:opacity-10 blur-xl transition-opacity duration-500" />
              <div className="relative p-8 rounded-2xl border border-gold-amber/20 hover:border-gold-amber/50 transition-all duration-300">
                <div className="w-16 h-16 rounded-xl bg-gold-amber/10 flex items-center justify-center mb-6">
                  <Sparkles className="w-8 h-8 text-gold-amber" />
                </div>
                <h4 className="text-2xl font-display font-bold mb-4">
                  AI-Guided Healing
                </h4>
                <p className="text-white/60 leading-relaxed">
                  Premium members receive compassionate AI insights, affirmations, and reflection 
                  prompts tailored to each confession.
                </p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-cosmic opacity-0 group-hover:opacity-10 blur-xl transition-opacity duration-500" />
              <div className="relative p-8 rounded-2xl border border-ember-glow/20 hover:border-ember-glow/50 transition-all duration-300">
                <div className="w-16 h-16 rounded-xl bg-ember-glow/10 flex items-center justify-center mb-6">
                  <Zap className="w-8 h-8 text-ember-glow" />
                </div>
                <h4 className="text-2xl font-display font-bold mb-4">
                  Soul Mirror Evolution
                </h4>
                <p className="text-white/60 leading-relaxed">
                  Watch your avatar evolve from Awakening to Transcendent as you build 
                  streaks and deepen your healing journey.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative py-32 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-4xl md:text-5xl font-display font-bold mb-8">
            Your Darkness Holds Light
          </h3>
          <p className="text-xl text-white/70 mb-12 max-w-2xl mx-auto">
            Join thousands who trust RYVYNN to hold their truth in complete privacy.
          </p>
          <Link
            href="/auth"
            className="inline-flex items-center gap-3 px-10 py-5 bg-gradient-cosmic rounded-xl font-display font-semibold text-lg shadow-2xl hover:shadow-violet-electric/50 transition-all duration-300"
          >
            Begin Free Today
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-white/40 text-sm">
            © 2025 RYVYNN. Privacy-first healing AI platform.
          </p>
          <div className="flex gap-8 text-sm text-white/40">
            <Link href="/privacy" className="hover:text-white/70 transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-white/70 transition-colors">
              Terms of Service
            </Link>
            <Link href="/security" className="hover:text-white/70 transition-colors">
              Security
            </Link>
          </div>
        </div>
      </footer>
    </main>
  );
}
