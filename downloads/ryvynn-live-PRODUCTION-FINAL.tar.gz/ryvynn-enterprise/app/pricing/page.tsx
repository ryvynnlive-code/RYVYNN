import Link from 'next/link';
import { Check, Sparkles, Zap, Crown } from 'lucide-react';

export default function PricingPage() {
  const tiers = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      description: 'Begin your healing journey',
      icon: Sparkles,
      color: 'violet',
      features: [
        '3 confessions per month',
        'Soul Mirror avatar',
        'End-to-end encryption',
        'Trust metrics tracking',
        'Basic emotional insights',
      ],
      cta: 'Start Free',
      href: '/auth',
    },
    {
      name: 'Premium',
      price: '$9',
      period: 'per month',
      description: 'Unlimited healing with AI guidance',
      icon: Zap,
      color: 'gold',
      popular: true,
      features: [
        'Unlimited confessions',
        'AI-powered insights & affirmations',
        'Advanced Soul Mirror evolution',
        'Detailed trust metrics',
        'Export your journal',
        'Priority support',
        'Future AI features early access',
      ],
      cta: 'Upgrade to Premium',
      href: '/auth?plan=premium',
    },
    {
      name: 'White Label',
      price: '$299',
      period: 'per month',
      description: 'Full platform for organizations',
      icon: Crown,
      color: 'ember',
      features: [
        'Everything in Premium',
        'Custom branding & domain',
        'Multi-client management',
        'Therapist dashboard',
        'Organization admin panel',
        'Client analytics',
        'Dedicated support',
        'Custom integrations',
      ],
      cta: 'Contact Sales',
      href: '/contact',
    },
  ];

  return (
    <main className="min-h-screen bg-cosmic-dark text-white">
      {/* Header */}
      <header className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <Link href="/" className="text-2xl font-display font-bold bg-gradient-cosmic bg-clip-text text-transparent">
            RYVYNN
          </Link>
          <Link
            href="/dashboard"
            className="px-6 py-2 rounded-lg border border-violet-electric/30 hover:border-violet-electric hover:bg-violet-electric/10 transition-all"
          >
            Dashboard
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 px-6 text-center">
        <h1 className="text-5xl md:text-6xl font-display font-bold mb-6">
          Choose Your{' '}
          <span className="bg-gradient-cosmic bg-clip-text text-transparent">
            Healing Path
          </span>
        </h1>
        <p className="text-xl text-white/60 max-w-2xl mx-auto">
          All plans include military-grade encryption and zero data harvesting. 
          Your privacy is absolute.
        </p>
      </section>

      {/* Pricing Cards */}
      <section className="pb-32 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-8">
          {tiers.map((tier) => {
            const Icon = tier.icon;
            const borderColor = tier.color === 'violet' ? 'border-violet-electric/30' :
                               tier.color === 'gold' ? 'border-gold-amber/30' :
                               'border-ember-glow/30';
            const iconBg = tier.color === 'violet' ? 'bg-violet-electric/10' :
                          tier.color === 'gold' ? 'bg-gold-amber/10' :
                          'bg-ember-glow/10';
            const iconColor = tier.color === 'violet' ? 'text-violet-electric' :
                             tier.color === 'gold' ? 'text-gold-amber' :
                             'text-ember-glow';

            return (
              <div
                key={tier.name}
                className={`relative rounded-2xl border-2 ${borderColor} p-8 ${
                  tier.popular ? 'md:scale-105 shadow-2xl' : ''
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 bg-gradient-cosmic rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                )}

                <div className={`w-16 h-16 rounded-xl ${iconBg} flex items-center justify-center mb-6`}>
                  <Icon className={`w-8 h-8 ${iconColor}`} />
                </div>

                <h3 className="text-2xl font-display font-bold mb-2">
                  {tier.name}
                </h3>
                <p className="text-white/50 mb-6">{tier.description}</p>

                <div className="mb-8">
                  <span className="text-5xl font-display font-bold">{tier.price}</span>
                  <span className="text-white/50 ml-2">/ {tier.period}</span>
                </div>

                <Link
                  href={tier.href}
                  className={`block w-full py-4 rounded-xl text-center font-display font-semibold mb-8 transition-all ${
                    tier.popular
                      ? 'bg-gradient-cosmic hover:shadow-xl'
                      : 'border border-white/20 hover:border-white/40 hover:bg-white/5'
                  }`}
                >
                  {tier.cta}
                </Link>

                <ul className="space-y-4">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <Check className={`w-5 h-5 ${iconColor} flex-shrink-0 mt-0.5`} />
                      <span className="text-white/70">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-6 border-t border-white/10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-display font-bold text-center mb-16">
            Frequently Asked Questions
          </h2>

          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-display font-semibold mb-2">
                Is my data really private?
              </h3>
              <p className="text-white/60">
                Absolutely. Every confession is encrypted with AES-256-GCM before leaving your device. 
                RYVYNN cannot read your confessions. We never sell or harvest your data.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-display font-semibold mb-2">
                Can I cancel anytime?
              </h3>
              <p className="text-white/60">
                Yes. Cancel your Premium subscription anytime from your dashboard. 
                No hidden fees or commitments.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-display font-semibold mb-2">
                What happens to my free confessions after upgrading?
              </h3>
              <p className="text-white/60">
                All your confessions remain encrypted and accessible. Upgrading unlocks unlimited 
                new confessions and AI insights for all future entries.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
