import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/supabase';
import { getUserTierInfo } from '@/lib/tier';

export async function GET(req: NextRequest) {
  try {
    const supabaseUser = await getCurrentUser();
    if (!supabaseUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { supabaseId: supabaseUser.id },
      select: {
        id: true,
        email: true,
        name: true,
        tier: true,
        totalConfessions: true,
        currentStreak: true,
        longestStreak: true,
        lastConfessionDate: true,
        soulPhase: true,
        emotionalBalance: true,
        createdAt: true,
        stripeCurrentPeriodEnd: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const tierInfo = await getUserTierInfo(user.id);

    return NextResponse.json({
      ...user,
      tierInfo,
    });

  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const supabaseUser = await getCurrentUser();
    if (!supabaseUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name } = await req.json();

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 });
    }

    const user = await prisma.user.update({
      where: { supabaseId: supabaseUser.id },
      data: { name: name.trim() },
      select: {
        id: true,
        email: true,
        name: true,
        tier: true,
      },
    });

    return NextResponse.json(user);

  } catch (error) {
    console.error('Update user error:', error);
    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    );
  }
}
