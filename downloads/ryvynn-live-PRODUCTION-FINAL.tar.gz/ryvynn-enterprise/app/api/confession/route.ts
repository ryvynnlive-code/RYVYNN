import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/supabase';
import { encrypt } from '@/lib/encryption';
import { analyzeSentiment, generateAIInsight, calculateSoulPhase } from '@/lib/ai';
import { canCreateConfession, hasFeatureAccess } from '@/lib/tier';

export async function POST(req: NextRequest) {
  try {
    // Authenticate user
    const supabaseUser = await getCurrentUser();
    if (!supabaseUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get user from database
    const user = await prisma.user.findUnique({
      where: { supabaseId: supabaseUser.id },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Check tier limits
    const canCreate = await canCreateConfession(user.id);
    if (!canCreate.allowed) {
      return NextResponse.json(
        { error: canCreate.reason, current: canCreate.current, limit: canCreate.limit },
        { status: 403 }
      );
    }

    // Parse request body
    const { content } = await req.json();

    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json({ error: 'Confession content is required' }, { status: 400 });
    }

    // Analyze sentiment
    const analysis = analyzeSentiment(content);

    // Encrypt confession
    const { encrypted, iv, authTag } = encrypt(content);

    // Generate AI insight for premium users
    let aiInsight = null;
    const hasAI = await hasFeatureAccess(user.id, 'ai_insights');
    if (hasAI) {
      const insight = await generateAIInsight(content, analysis.sentiment);
      aiInsight = `${insight.insight}\n\n💜 ${insight.affirmation}\n\n🤔 ${insight.reflectionPrompt}`;
    }

    // Calculate streak
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    let newStreak = 1;
    if (user.lastConfessionDate) {
      const lastDate = new Date(user.lastConfessionDate);
      lastDate.setHours(0, 0, 0, 0);
      
      if (lastDate.getTime() === yesterday.getTime()) {
        newStreak = user.currentStreak + 1;
      } else if (lastDate.getTime() !== today.getTime()) {
        newStreak = 1;
      } else {
        newStreak = user.currentStreak;
      }
    }

    // Create confession and update user in transaction
    const confession = await prisma.$transaction(async (tx) => {
      const newConfession = await tx.confession.create({
        data: {
          userId: user.id,
          encryptedContent: encrypted,
          encryptedKey: authTag,
          iv,
          wordCount: analysis.wordCount,
          sentiment: analysis.sentiment,
          intensity: analysis.intensity,
          tags: analysis.tags,
          aiInsight,
          aiGenerated: hasAI,
        },
      });

      // Update user metrics
      const totalConfessions = user.totalConfessions + 1;
      const emotionalBalance = calculateEmotionalBalance(analysis.sentiment, user.emotionalBalance);
      const soulPhase = calculateSoulPhase(totalConfessions, newStreak, emotionalBalance);

      await tx.user.update({
        where: { id: user.id },
        data: {
          totalConfessions,
          currentStreak: newStreak,
          longestStreak: Math.max(newStreak, user.longestStreak),
          lastConfessionDate: new Date(),
          emotionalBalance,
          soulPhase,
        },
      });

      return newConfession;
    });

    return NextResponse.json({
      id: confession.id,
      sentiment: confession.sentiment,
      intensity: confession.intensity,
      tags: confession.tags,
      aiInsight: confession.aiInsight,
      streak: newStreak,
      createdAt: confession.createdAt,
    });

  } catch (error) {
    console.error('Confession creation error:', error);
    return NextResponse.json(
      { error: 'Failed to create confession' },
      { status: 500 }
    );
  }
}

function calculateEmotionalBalance(
  newSentiment: string,
  currentBalance: number
): number {
  const sentimentValue = {
    positive: 0.1,
    neutral: 0,
    negative: -0.1,
  }[newSentiment] || 0;

  const newBalance = currentBalance * 0.7 + (0.5 + sentimentValue) * 0.3;
  return Math.max(0, Math.min(1, newBalance));
}
