#!/bin/bash
# RYVYNN Enterprise - Live Deployment Script
# Domain: Ryvynn.live
# Accounts: founder.soulos@gmail.com (Vercel, GitHub, Supabase)

echo "🚀 RYVYNN ENTERPRISE - DEPLOYING TO RYVYNN.LIVE"
echo "================================================"
echo ""

# Check prerequisites
command -v git >/dev/null 2>&1 || { echo "❌ Git not installed"; exit 1; }
command -v node >/dev/null 2>&1 || { echo "❌ Node.js not installed"; exit 1; }

echo "✅ Prerequisites checked"
echo ""

# Generate encryption key
echo "🔐 Generating encryption key..."
ENCRYPTION_KEY=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64'))")
echo "Generated: $ENCRYPTION_KEY"
echo ""

echo "📋 DEPLOYMENT STEPS:"
echo ""
echo "1️⃣  GITHUB SETUP"
echo "   Go to: https://github.com/new"
echo "   - Repository name: ryvynn-enterprise"
echo "   - Visibility: Private"
echo "   - Don't initialize with README"
echo "   - Click 'Create repository'"
echo ""

read -p "Press Enter when GitHub repo is created..."

echo ""
echo "2️⃣  PUSHING TO GITHUB"
read -p "Enter your GitHub repo URL (https://github.com/YOUR-USERNAME/ryvynn-enterprise.git): " REPO_URL

git remote add origin "$REPO_URL" 2>/dev/null || git remote set-url origin "$REPO_URL"
git push -u origin main

echo ""
echo "✅ Code pushed to GitHub!"
echo ""

echo "3️⃣  VERCEL DEPLOYMENT"
echo "   Go to: https://vercel.com/new"
echo "   - Sign in with: founder.soulos@gmail.com"
echo "   - Select your team: Foundersoulos"
echo "   - Import the GitHub repo: ryvynn-enterprise"
echo "   - Click 'Deploy'"
echo ""

read -p "Press Enter when Vercel deployment starts..."

echo ""
echo "4️⃣  ENVIRONMENT VARIABLES"
echo "   In Vercel Dashboard → Settings → Environment Variables, add:"
echo ""
echo "   ENCRYPTION_KEY=$ENCRYPTION_KEY"
echo ""
echo "   Then add these (get from your accounts):"
echo ""
cat << 'ENVVARS'
   NEXT_PUBLIC_APP_URL=https://ryvynn.live
   NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
   DATABASE_URL=postgresql://postgres:[PASSWORD]@db.xxxxx.supabase.co:6543/postgres?pgbouncer=true
   DIRECT_URL=postgresql://postgres:[PASSWORD]@db.xxxxx.supabase.co:5432/postgres
   STRIPE_SECRET_KEY=sk_live_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
   STRIPE_PREMIUM_MONTHLY_PRICE_ID=price_...
   STRIPE_PREMIUM_ANNUAL_PRICE_ID=price_...
   STRIPE_WHITE_LABEL_PRICE_ID=price_...
ENVVARS
echo ""

read -p "Press Enter when environment variables are set..."

echo ""
echo "5️⃣  CUSTOM DOMAIN (Ryvynn.live)"
echo "   In Vercel Dashboard → Domains:"
echo "   - Add domain: ryvynn.live"
echo "   - Add domain: www.ryvynn.live"
echo ""
echo "   Update DNS at your registrar:"
echo "   A Record:    @    →  76.76.21.21"
echo "   CNAME:       www  →  cname.vercel-dns.com"
echo ""

read -p "Press Enter when domain is configured..."

echo ""
echo "6️⃣  DATABASE MIGRATION"
echo "   Run these commands:"
echo ""
echo "   npx prisma generate"
echo "   npx prisma migrate deploy"
echo ""

read -p "Press Enter to run migrations now (y/n): " RUN_MIGRATIONS

if [[ $RUN_MIGRATIONS == "y" ]]; then
    npx prisma generate
    npx prisma migrate deploy
    echo "✅ Database migrated!"
fi

echo ""
echo "7️⃣  STRIPE WEBHOOK"
echo "   In Stripe Dashboard → Webhooks:"
echo "   - Endpoint: https://ryvynn.live/api/stripe/webhook"
echo "   - Events: checkout.session.completed, customer.subscription.*"
echo "   - Copy signing secret → Add to Vercel as STRIPE_WEBHOOK_SECRET"
echo ""

echo ""
echo "🎉 DEPLOYMENT COMPLETE!"
echo ""
echo "Visit: https://ryvynn.live"
echo ""
echo "✅ RYVYNN Enterprise is LIVE!"
