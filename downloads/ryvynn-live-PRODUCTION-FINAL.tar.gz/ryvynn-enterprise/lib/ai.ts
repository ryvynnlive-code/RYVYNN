/**
 * Analyze sentiment and generate insights for confessions
 * This is a simplified version - in production, integrate with OpenAI API
 */

export interface SentimentAnalysis {
  sentiment: 'positive' | 'neutral' | 'negative';
  intensity: number; // 0-1 scale
  tags: string[];
  wordCount: number;
}

export interface AIInsight {
  insight: string;
  affirmation: string;
  reflectionPrompt: string;
}

/**
 * Analyze confession text for sentiment and metadata
 */
export function analyzeSentiment(text: string): SentimentAnalysis {
  const wordCount = text.split(/\s+/).length;
  
  // Simple keyword-based sentiment (replace with AI in production)
  const positiveWords = ['happy', 'grateful', 'love', 'joy', 'peace', 'hope', 'better', 'growth', 'healing'];
  const negativeWords = ['sad', 'angry', 'hurt', 'pain', 'fear', 'anxiety', 'worry', 'stress', 'lost'];
  
  const lowerText = text.toLowerCase();
  
  let positiveCount = 0;
  let negativeCount = 0;
  
  positiveWords.forEach(word => {
    if (lowerText.includes(word)) positiveCount++;
  });
  
  negativeWords.forEach(word => {
    if (lowerText.includes(word)) negativeCount++;
  });
  
  let sentiment: 'positive' | 'neutral' | 'negative' = 'neutral';
  if (positiveCount > negativeCount) sentiment = 'positive';
  if (negativeCount > positiveCount) sentiment = 'negative';
  
  const intensity = Math.min((positiveCount + negativeCount) / 10, 1);
  
  // Extract tags (simplified - use NLP in production)
  const tags = extractTags(text);
  
  return {
    sentiment,
    intensity,
    tags,
    wordCount,
  };
}

/**
 * Generate AI insight for confession (Premium feature)
 */
export async function generateAIInsight(
  text: string,
  sentiment: string
): Promise<AIInsight> {
  // In production, call OpenAI API with proper prompt engineering
  // For now, return template-based insights
  
  const insights = {
    positive: {
      insight: "Your words reflect growth and self-awareness. This moment of clarity is powerful.",
      affirmation: "You are actively choosing healing over hiding.",
      reflectionPrompt: "What strength did you discover in yourself today?",
    },
    neutral: {
      insight: "Processing complex emotions takes courage. You're creating space for understanding.",
      affirmation: "Your journey is valid, even in the in-between moments.",
      reflectionPrompt: "What would it feel like to be gentle with yourself right now?",
    },
    negative: {
      insight: "Naming difficult emotions is an act of bravery. You're not alone in this darkness.",
      affirmation: "Even in pain, you are worthy of compassion and care.",
      reflectionPrompt: "What would you tell a friend who shared these same feelings?",
    },
  };
  
  return insights[sentiment as keyof typeof insights] || insights.neutral;
}

/**
 * Extract thematic tags from text
 */
function extractTags(text: string): string[] {
  const themes = {
    relationships: ['relationship', 'partner', 'friend', 'family', 'love', 'connection'],
    work: ['work', 'job', 'career', 'stress', 'boss', 'colleague'],
    mental_health: ['anxiety', 'depression', 'therapy', 'medication', 'mental health'],
    self_worth: ['confidence', 'self-esteem', 'worth', 'value', 'enough'],
    growth: ['growth', 'healing', 'progress', 'change', 'better'],
    loss: ['loss', 'grief', 'death', 'goodbye', 'missing'],
  };
  
  const lowerText = text.toLowerCase();
  const tags: string[] = [];
  
  Object.entries(themes).forEach(([tag, keywords]) => {
    if (keywords.some(keyword => lowerText.includes(keyword))) {
      tags.push(tag);
    }
  });
  
  return tags.slice(0, 3); // Return max 3 tags
}

/**
 * Calculate soul phase based on user metrics
 */
export function calculateSoulPhase(
  totalConfessions: number,
  currentStreak: number,
  emotionalBalance: number
): 'awakening' | 'growing' | 'healing' | 'transcendent' {
  if (totalConfessions < 5 || currentStreak < 3) return 'awakening';
  if (totalConfessions < 20 || emotionalBalance < 0.5) return 'growing';
  if (totalConfessions < 50 || currentStreak < 14) return 'healing';
  return 'transcendent';
}
