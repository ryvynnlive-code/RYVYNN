import { prisma } from './prisma';

/**
 * Tier limits configuration
 */
export const TIER_LIMITS = {
  free: {
    monthlyConfessions: 3,
    features: ['basic_confession', 'soul_mirror'],
  },
  premium: {
    monthlyConfessions: Infinity,
    features: ['basic_confession', 'soul_mirror', 'ai_insights', 'trust_metrics', 'export'],
  },
  whitelabel: {
    monthlyConfessions: Infinity,
    features: ['all'],
  },
};

/**
 * Check if user can create confession based on tier
 */
export async function canCreateConfession(userId: string): Promise<{
  allowed: boolean;
  reason?: string;
  current: number;
  limit: number;
}> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      tier: true,
      totalConfessions: true,
      createdAt: true,
    },
  });

  if (!user) {
    return { allowed: false, reason: 'User not found', current: 0, limit: 0 };
  }

  // Premium and whitelabel have unlimited confessions
  if (user.tier === 'premium' || user.tier === 'whitelabel') {
    return { allowed: true, current: user.totalConfessions, limit: Infinity };
  }

  // For free tier, count confessions this month
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const monthlyCount = await prisma.confession.count({
    where: {
      userId,
      createdAt: {
        gte: startOfMonth,
      },
    },
  });

  const limit = TIER_LIMITS.free.monthlyConfessions;
  const allowed = monthlyCount < limit;

  return {
    allowed,
    reason: allowed ? undefined : 'Monthly confession limit reached. Upgrade to Premium for unlimited confessions.',
    current: monthlyCount,
    limit,
  };
}

/**
 * Check if user has access to specific feature
 */
export async function hasFeatureAccess(
  userId: string,
  feature: string
): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { tier: true },
  });

  if (!user) return false;

  const tierFeatures = TIER_LIMITS[user.tier as keyof typeof TIER_LIMITS]?.features || [];
  
  return tierFeatures.includes('all') || tierFeatures.includes(feature);
}

/**
 * Get user tier info
 */
export async function getUserTierInfo(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      tier: true,
      stripeCurrentPeriodEnd: true,
      totalConfessions: true,
    },
  });

  if (!user) return null;

  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const monthlyConfessions = await prisma.confession.count({
    where: {
      userId,
      createdAt: {
        gte: startOfMonth,
      },
    },
  });

  const tierConfig = TIER_LIMITS[user.tier as keyof typeof TIER_LIMITS];

  return {
    tier: user.tier,
    features: tierConfig?.features || [],
    monthlyConfessions,
    monthlyLimit: tierConfig?.monthlyConfessions || 0,
    subscriptionEnd: user.stripeCurrentPeriodEnd,
  };
}
