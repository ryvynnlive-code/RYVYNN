# 🚀 RYVYNN.LIVE - QUICKSTART DEPLOYMENT

**All accounts:** founder.soulos@gmail.com  
**Domain:** Ryvynn.live  
**Team:** Foundersoulos (Vercel)

---

## ⚡ 3-STEP DEPLOYMENT

### 1. CREATE GITHUB REPO
```
https://github.com/new
- Name: ryvynn-enterprise
- Private: Yes
- Don't initialize
```

### 2. PUSH CODE
```bash
cd ryvynn-enterprise
git remote add origin https://github.com/YOUR-USERNAME/ryvynn-enterprise.git
git push -u origin main
```

### 3. DEPLOY ON VERCEL
```
https://vercel.com/new
- Import ryvynn-enterprise repo
- Add environment variables (see below)
- Deploy
```

---

## 🔑 ENVIRONMENT VARIABLES

**Generate encryption key:**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

**Add to Vercel:**
```env
ENCRYPTION_KEY=<generated-above>
NEXT_PUBLIC_APP_URL=https://ryvynn.live

# Supabase (from supabase.com dashboard)
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
DATABASE_URL=postgresql://...?pgbouncer=true
DIRECT_URL=postgresql://...

# Stripe (from stripe.com dashboard)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_PREMIUM_MONTHLY_PRICE_ID=price_...
STRIPE_PREMIUM_ANNUAL_PRICE_ID=price_...
STRIPE_WHITE_LABEL_PRICE_ID=price_...
```

---

## 🌐 CUSTOM DOMAIN

**Vercel Dashboard → Domains:**
- Add: `ryvynn.live`
- Add: `www.ryvynn.live`

**DNS Settings (at registrar):**
```
A      @    →  76.76.21.21
CNAME  www  →  cname.vercel-dns.com
```

---

## 💾 DATABASE MIGRATION

```bash
npx prisma generate
npx prisma migrate deploy
```

---

## 💳 STRIPE WEBHOOK

**Stripe Dashboard → Webhooks:**
- Endpoint: `https://ryvynn.live/api/stripe/webhook`
- Events: Select all subscription events
- Copy webhook secret → Add to Vercel

---

## ✅ YOU'RE LIVE!

Visit: **https://ryvynn.live**

Test:
1. Sign up
2. Create confession
3. View Soul Mirror
4. Upgrade to Premium

---

**Total time:** ~10 minutes
