# 🚀 RYVYNN ENTERPRISE - IMMEDIATE DEPLOYMENT GUIDE

**Email for deployment:** ryvynn.live@gmail.com

---

## ⚡ FASTEST DEPLOYMENT (5 MINUTES)

### Step 1: Download & Extract
Download: [ryvynn-enterprise-DEPLOY-READY.tar.gz](computer:///mnt/user-data/outputs/ryvynn-enterprise-DEPLOY-READY.tar.gz)

```bash
# Extract
tar -xzf ryvynn-enterprise-DEPLOY-READY.tar.gz
cd ryvynn-enterprise
```

### Step 2: Deploy to Vercel
```bash
# Install Vercel CLI (if needed)
npm i -g vercel

# Login with ryvynn.live@gmail.com
vercel login

# Deploy to production
vercel --prod

# Follow prompts:
# - Link to existing project? No
# - Project name: ryvynn-enterprise
# - Directory: ./ (press Enter)
# - Override settings? No
```

**Vercel will:**
- ✅ Create GitHub repo automatically
- ✅ Deploy to production
- ✅ Give you live URL

### Step 3: Configure Environment Variables

After deployment, add these in Vercel dashboard:

```bash
# Generate encryption key first:
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

Then in Vercel → Settings → Environment Variables:

```env
# App
NEXT_PUBLIC_APP_URL=https://ryvynn-enterprise.vercel.app

# Encryption (use output from above command)
ENCRYPTION_KEY=<YOUR_GENERATED_KEY>

# Supabase (get from supabase.com dashboard)
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
DATABASE_URL=postgresql://postgres:[PASSWORD]@db.xxxxx.supabase.co:6543/postgres?pgbouncer=true
DIRECT_URL=postgresql://postgres:[PASSWORD]@db.xxxxx.supabase.co:5432/postgres

# Stripe (get from stripe.com dashboard)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_PREMIUM_MONTHLY_PRICE_ID=price_...
STRIPE_PREMIUM_ANNUAL_PRICE_ID=price_...
STRIPE_WHITE_LABEL_PRICE_ID=price_...
```

### Step 4: Run Database Migration

```bash
# Pull environment variables locally
vercel env pull .env.production.local

# Run Prisma migration
npx prisma migrate deploy
```

### Step 5: Configure Stripe Webhook

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://your-app.vercel.app/api/stripe/webhook`
3. Select events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
4. Copy webhook signing secret to `STRIPE_WEBHOOK_SECRET` in Vercel

### Step 6: Redeploy

```bash
vercel --prod
```

---

## 🎯 YOU'RE LIVE!

Visit your app at the Vercel URL. Test:
1. Sign up with email
2. Create encrypted confession
3. View Soul Mirror avatar
4. Check trust metrics

---

## 📦 WHAT'S INCLUDED

- ✅ **27 production files**
- ✅ **Next.js 15** with App Router
- ✅ **AES-256-GCM** encryption
- ✅ **Supabase Auth** ready
- ✅ **Stripe Subscriptions** configured
- ✅ **Prisma ORM** + PostgreSQL
- ✅ **Cosmic-dark UI** with golden ratio
- ✅ **Zero-surveillance** architecture

---

## 🆘 NEED HELP?

If you get stuck:
1. Check Vercel deployment logs
2. Verify all environment variables are set
3. Ensure Supabase project is created
4. Confirm Stripe webhooks are configured

**Support:** shawn@ryvynn.com

---

**Total deployment time: ~5 minutes**
