'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

interface ConfessionInputProps {
  onSubmit: (content: string) => Promise<void>;
  tier: string;
  monthlyUsed: number;
  monthlyLimit: number;
}

export function ConfessionInput({ onSubmit, tier, monthlyUsed, monthlyLimit }: ConfessionInputProps) {
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [charCount, setCharCount] = useState(0);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setContent(text);
    setCharCount(text.length);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!content.trim()) {
      toast.error('Please write something before submitting');
      return;
    }

    if (tier === 'free' && monthlyUsed >= monthlyLimit) {
      toast.error('Monthly limit reached. Upgrade to Premium for unlimited confessions.');
      return;
    }

    setIsSubmitting(true);

    try {
      await onSubmit(content);
      setContent('');
      setCharCount(0);
      toast.success('Confession saved securely');
    } catch (error: any) {
      toast.error(error.message || 'Failed to save confession');
    } finally {
      setIsSubmitting(false);
    }
  };

  const progress = tier === 'free' ? (monthlyUsed / monthlyLimit) * 100 : 0;
  const canSubmit = tier !== 'free' || monthlyUsed < monthlyLimit;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-4xl mx-auto"
    >
      <form onSubmit={handleSubmit} className="relative">
        {/* Cosmic Background Glow */}
        <div className="absolute inset-0 bg-gradient-cosmic opacity-10 blur-3xl -z-10" />

        <div className="relative">
          {/* Sacred Geometry Border */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-electric/20 to-gold-amber/20 p-[2px]">
            <div className="h-full w-full rounded-2xl bg-cosmic-dark" />
          </div>

          <textarea
            value={content}
            onChange={handleChange}
            placeholder="What weighs on your soul? Speak freely... your words are encrypted and private."
            disabled={isSubmitting || !canSubmit}
            className="relative w-full h-48 px-8 py-6 bg-transparent text-white placeholder-white/30 rounded-2xl resize-none focus:outline-none font-sans text-lg leading-relaxed"
            maxLength={5000}
          />
        </div>

        <div className="flex items-center justify-between mt-4 px-2">
          <div className="flex items-center gap-4">
            <span className="text-sm text-white/50">
              {charCount} / 5000
            </span>

            {tier === 'free' && (
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-cosmic-deep rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-violet-electric to-gold-amber"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <span className="text-xs text-white/40">
                  {monthlyUsed} / {monthlyLimit} this month
                </span>
              </div>
            )}
          </div>

          <motion.button
            type="submit"
            disabled={isSubmitting || !canSubmit || !content.trim()}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-3 rounded-xl bg-gradient-cosmic text-white font-display font-semibold disabled:opacity-40 disabled:cursor-not-allowed shadow-lg"
          >
            {isSubmitting ? 'Encrypting...' : 'Release'}
          </motion.button>
        </div>

        {!canSubmit && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 text-center text-sm text-ember-glow"
          >
            Monthly limit reached. <a href="/pricing" className="underline">Upgrade to Premium</a> for unlimited confessions.
          </motion.p>
        )}
      </form>
    </motion.div>
  );
}
