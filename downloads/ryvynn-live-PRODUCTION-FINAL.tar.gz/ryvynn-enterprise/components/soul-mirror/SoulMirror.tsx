'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface SoulMirrorProps {
  phase: 'awakening' | 'growing' | 'healing' | 'transcendent';
  emotionalBalance: number;
  streak: number;
  className?: string;
}

export function SoulMirror({ phase, emotionalBalance, streak, className = '' }: SoulMirrorProps) {
  const [rings, setRings] = useState<number>(2);
  const [particleCount, setParticleCount] = useState<number>(12);

  useEffect(() => {
    // Evolve complexity based on phase
    const phaseConfig = {
      awakening: { rings: 2, particles: 12 },
      growing: { rings: 3, particles: 24 },
      healing: { rings: 4, particles: 36 },
      transcendent: { rings: 5, particles: 48 },
    };
    
    setRings(phaseConfig[phase].rings);
    setParticleCount(phaseConfig[phase].particles);
  }, [phase]);

  // Color interpolation: violet (low) → gold (high)
  const getGradientColor = () => {
    const violet = { r: 166, g: 99, b: 255 };
    const gold = { r: 255, g: 216, b: 110 };
    
    const r = Math.round(violet.r + (gold.r - violet.r) * emotionalBalance);
    const g = Math.round(violet.g + (gold.g - violet.g) * emotionalBalance);
    const b = Math.round(violet.b + (gold.b - violet.b) * emotionalBalance);
    
    return `rgb(${r}, ${g}, ${b})`;
  };

  const primaryColor = getGradientColor();
  const phi = 1.618033988749; // Golden ratio

  return (
    <div className={`relative ${className}`}>
      <svg
        viewBox="0 0 400 400"
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 0 30px rgba(166, 99, 255, 0.5))' }}
      >
        <defs>
          <radialGradient id="coreGlow" cx="50%" cy="50%">
            <stop offset="0%" stopColor={primaryColor} stopOpacity="1" />
            <stop offset="100%" stopColor={primaryColor} stopOpacity="0" />
          </radialGradient>
          
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Central Core */}
        <motion.circle
          cx="200"
          cy="200"
          r="30"
          fill="url(#coreGlow)"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Orbital Rings */}
        {Array.from({ length: rings }).map((_, i) => {
          const radius = 50 + i * 40 * Math.pow(phi, 0.5);
          const rotationDuration = 20 + i * 10;
          
          return (
            <motion.circle
              key={`ring-${i}`}
              cx="200"
              cy="200"
              r={radius}
              fill="none"
              stroke={primaryColor}
              strokeWidth={2 - i * 0.3}
              strokeOpacity={0.6 - i * 0.1}
              filter="url(#glow)"
              animate={{
                rotate: [0, 360],
                strokeOpacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                rotate: {
                  duration: rotationDuration,
                  repeat: Infinity,
                  ease: 'linear',
                },
                strokeOpacity: {
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                },
              }}
              style={{ originX: '50%', originY: '50%' }}
            />
          );
        })}

        {/* Fractal Particles */}
        {Array.from({ length: particleCount }).map((_, i) => {
          const angle = (i / particleCount) * Math.PI * 2;
          const radius = 80 + (i % 3) * 30;
          const x = 200 + Math.cos(angle * phi) * radius;
          const y = 200 + Math.sin(angle * phi) * radius;
          const size = 3 + (i % 4);
          const delay = (i / particleCount) * 2;

          return (
            <motion.circle
              key={`particle-${i}`}
              cx={x}
              cy={y}
              r={size}
              fill={primaryColor}
              opacity={0.7}
              filter="url(#glow)"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.4, 0.8, 0.4],
                x: [0, Math.cos(angle) * 10, 0],
                y: [0, Math.sin(angle) * 10, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'easeInOut',
                delay,
              }}
            />
          );
        })}

        {/* Streak Lightning */}
        {streak > 0 && (
          <motion.path
            d={`M ${200 + 60} ${200} L ${200 + 80} ${200 - 10} L ${200 + 70} ${200} L ${200 + 90} ${200 + 10} Z`}
            fill={primaryColor}
            opacity={0.8}
            animate={{
              opacity: [0, 1, 0],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            style={{ originX: '50%', originY: '50%' }}
          />
        )}
      </svg>

      {/* Phase Label */}
      <motion.div
        className="absolute bottom-0 left-1/2 transform -translate-x-1/2 text-center"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <p className="text-sm font-display text-white/70 capitalize tracking-widest">
          {phase}
        </p>
        {streak > 0 && (
          <p className="text-xs text-violet-electric mt-1">
            🔥 {streak} day streak
          </p>
        )}
      </motion.div>
    </div>
  );
}
