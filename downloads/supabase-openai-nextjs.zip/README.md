# Supabase&nbsp;+ OpenAI GPT‑5 Next.js Skeleton

This repository provides a ready‑to‑deploy Next.js application that integrates
Supabase (as a backend database, authentication and real‑time service) with
OpenAI’s GPT‑5 model.  The goal of this skeleton is to demonstrate a clean,
production‑ready way to bridge a serverless React app with both the Supabase
JavaScript SDK and the OpenAI API.

## Features

* **Next.js 15 App Router** — The new file system based routing makes it easy
  to build modern React applications with server components and API routes.
* **Supabase integration** — Uses `@supabase/supabase-js` to connect to your
  Supabase project.  An example API route stores user prompts and model
  responses in a `messages` table.
* **OpenAI GPT‑5 support** — A server‑side API route proxies requests to
  OpenAI’s chat completions endpoint so that your secret API key never
  appears in client code or the browser.
* **TypeScript by default** — End‑to‑end type safety for your codebase.
* **Docker & CI/CD** — Includes a simple Dockerfile for containerised
  deployment and a GitHub Actions workflow for continuous integration.

## Getting Started

1. **Clone the repository**:

   ```bash
   git clone https://github.com/your‑org/supabase-openai-nextjs.git
   cd supabase-openai-nextjs
   ```

2. **Install dependencies**:

   ```bash
   npm install
   ```

3. **Create a Supabase project** on [supabase.com](https://supabase.com/) and
   copy your `SUPABASE_URL` and `SUPABASE_ANON_KEY` into a `.env.local`
   file at the root of the project.  Also add your OpenAI API key.  Use
   `.env.example` as a reference.

4. **Create the `messages` table** in your Supabase database.  You can run
   the SQL in [`supabase.sql`](./supabase.sql) using the Supabase SQL editor
   or `psql`:

   ```sql
   -- supabase.sql
   create extension if not exists "uuid-ossp";
   create table if not exists public.messages (
     id uuid default uuid_generate_v4() primary key,
     user_id uuid,
     prompt text not null,
     response text not null,
     created_at timestamp with time zone default current_timestamp
   );
   ```

5. **Start the development server**:

   ```bash
   npm run dev
   ```

   The app will be available at [http://localhost:3000](http://localhost:3000).

## Environment Variables

Create a `.env.local` file and define the following variables (do not
commit this file to source control):

```env
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-anon-key
OPENAI_API_KEY=your-openai-api-key
```

## File Structure

```
supabase-openai-nextjs/
├── app/                  # Next.js app directory (App Router)
│   ├── api/
│   │   └── ai/           # API route for GPT‑5 integration
│   │       └── route.ts
│   └── page.tsx          # Simple home page with a prompt form
├── .github/
│   └── workflows/
│       └── ci.yml        # GitHub Actions workflow for CI
├── supabase.sql          # SQL to create the messages table
├── .env.example          # Example environment variables
├── .gitignore            # Standard ignore file
├── Dockerfile            # Containerisation instructions
├── next.config.js        # Next.js configuration
├── package.json          # Project metadata and scripts
├── tsconfig.json         # TypeScript configuration
└── README.md             # This file
```

## Security & Privacy

* **Server‑side API route** — All calls to OpenAI are made server‑side.  The
  client never sees your `OPENAI_API_KEY`.
* **Row level security** — Supabase RLS is disabled in this example for
  simplicity.  In production you should enable RLS and implement policies
  restricting access to data based on the authenticated user.
* **Secret management** — Never commit real API keys or Supabase service
  roles to version control.  Use environment variables and secrets in your
  deployment platform.

## Deployment

You can containerise the application using the provided `Dockerfile` and
deploy it to any platform supporting Docker (e.g. Vercel, Fly.io,
AWS Fargate).  Alternatively, deploy directly with Vercel for serverless
hosting; Next.js API routes run as serverless functions out of the box.

## License

This template is provided without any specific license.  Use it as a
starting point for your own projects.