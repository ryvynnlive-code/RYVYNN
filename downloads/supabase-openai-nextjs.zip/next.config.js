/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: [
      '@supabase/supabase-js',
      'openai',
    ],
  },
  reactStrictMode: true,
  // If you need to expose non‑sensitive environment variables to the client
  // you can prefix them with NEXT_PUBLIC_ and add them here
  // env: {
  //   NEXT_PUBLIC_SOME_KEY: process.env.NEXT_PUBLIC_SOME_KEY,
  // },
};

module.exports = nextConfig;