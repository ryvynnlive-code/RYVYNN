import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { createClient } from '@supabase/supabase-js';

// Initialize OpenAI and Supabase clients
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

/**
 * POST /api/ai
 *
 * Expects a JSON body with `{ prompt: string, user_id?: string }`.
 * Calls OpenAI GPT‑5 with the prompt and returns the AI response.  If a
 * `user_id` is provided, the prompt and response are stored in the
 * `messages` table.
 */
export async function POST(req: NextRequest) {
  try {
    const { prompt, user_id } = await req.json();
    if (!prompt || typeof prompt !== 'string') {
      return new NextResponse('Invalid prompt', { status: 400 });
    }

    // Call OpenAI to get a completion
    const completion = await openai.chat.completions.create({
      model: 'gpt-5',
      messages: [{ role: 'user', content: prompt }],
    });

    const aiMessage = completion.choices?.[0]?.message?.content ?? '';

    // Persist the exchange in Supabase (optional)
    if (user_id) {
      await supabase.from('messages').insert({
        user_id,
        prompt,
        response: aiMessage,
      });
    }

    return NextResponse.json({ aiMessage });
  } catch (err) {
    console.error(err);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}