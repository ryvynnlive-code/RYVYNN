-- Enable uuid generation if not already enabled
create extension if not exists "uuid-ossp";

-- Messages table to store prompts and AI responses
create table if not exists public.messages (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid null,
  prompt text not null,
  response text not null,
  created_at timestamp with time zone default current_timestamp
);