# RYVYNN — Founder Microsite + Investor Dossier (Static)
This bundle is production‑ready and deploys on any static host (Vercel, Netlify, S3).

## Files
- `index.html` — Founder front door
- `manifesto.html` — The RYVYNN Manifesto
- `waitlist.html` — Email capture (Formspree endpoint; replace with Supabase or Resend later)
- `investors.html` — Investor dossier (slide‑like sections)
- `styles.css` — Theme
- `assets/ryvynn.svg` — Logotype mark (swap with brand pack asset anytime)
- `vercel.json` — Security headers
- `README.md` — You are here

## Deploy (Vercel CLI)
```bash
vercel --prod
```
